"""Independent API gateway and inference roles: APP_ROLE=api|recommendation."""
import os,time,secrets
from uuid import UUID,uuid4
from typing import Literal
import httpx
from fastapi import FastAPI,HTTPException,Header
from pydantic import BaseModel,Field,field_validator
from sqlalchemy import text
from fastapi.responses import Response
from prometheus_client import Counter,Histogram,generate_latest,CONTENT_TYPE_LATEST
from .storage import Store,Conflict
from .cache import Cache
from .hybrid import Hybrid,PRODUCTS
app=FastAPI(title='Recommendation Platform',version='2.0')
store=Store();cache=Cache();model=Hybrid();role=os.getenv('APP_ROLE','api')
requests=Counter('platform_requests_total','HTTP responses',['role','method','status'])
latency=Histogram('platform_request_seconds','HTTP latency',['role'])
@app.middleware('http')
async def observe(request,call_next):
    start=time.perf_counter();status=500
    try:
        response=await call_next(request);status=response.status_code;return response
    finally:requests.labels(role,request.method,str(status)).inc();latency.labels(role).observe(time.perf_counter()-start)
@app.get('/metrics')
def metrics():return Response(generate_latest(),media_type=CONTENT_TYPE_LATEST)
@app.get('/health')
@app.get('/live')
def live():return {'status':'ok','service':role}
@app.get('/ready')
def ready():
    try:
        with store.engine.connect() as c:c.execute(text('SELECT version FROM signal_versions WHERE id=1')).scalar_one()
        return {'status':'ready'}
    except Exception:raise HTTPException(503,'Database unavailable or migration missing')
class Event(BaseModel):
    event_id:UUID=Field(default_factory=uuid4)
    user_id:str=Field(min_length=1,max_length=100)
    product_id:str
    event_type:Literal['view','click','purchase']
    dwell_seconds:float=Field(default=0,ge=0,le=36000,allow_inf_nan=False)
    @field_validator('user_id')
    @classmethod
    def user(cls,v):
        if not v.strip():raise ValueError('Blank user')
        return v.strip()
@app.get('/recommendations/{user_id}')
def recommendations(user_id:str,limit:int=5):
    limit=max(1,min(limit,12))
    if role=='api':
        try:
            r=httpx.get(os.getenv('RECOMMENDATION_URL','http://recommendation:8000')+'/recommendations/'+__import__('urllib.parse',fromlist=['quote']).quote(user_id,safe=''),params={'limit':limit},timeout=5)
            r.raise_for_status();return r.json()
        except httpx.HTTPError:raise HTTPException(503,'Recommendation service unavailable')
    version,history,signals=store.model_snapshot(user_id)
    key=cache.key(user_id,limit,'hybrid-v2-'+str(version));result=cache.get(key)
    if result is None:
        result={'user_id':user_id,'signal_version':version,'recommendations':model.recommend(history,signals,limit)};cache.put(key,result)
    return result
if role=='api':
    @app.get('/products')
    def products():return PRODUCTS
    @app.post('/events')
    def accept(event:Event):
        if event.product_id not in model.index:raise HTTPException(404,'Unknown product')
        try:store.accept(event.model_dump(mode='json'))
        except Conflict as e:raise HTTPException(409,str(e))
        return {'message':'event accepted','event':event.model_dump(mode='json'),'published_to_broker':False,'publication_status':'accepted; processing asynchronously'}
    @app.get('/events/{user_id}')
    def history(user_id:str):return store.history(user_id)
    @app.get('/trending')
    def trending():
        _,_,signals=store.model_snapshot('');return model.recommend([],signals,12,mode='popularity')
    @app.get('/admin/analytics')
    def analytics(x_admin_key:str=Header(default='')):
        configured=os.getenv('ADMIN_KEY','')
        if not configured or not secrets.compare_digest(configured,x_admin_key):raise HTTPException(401,'Admin key required')
        return store.analytics()
    @app.get('/system')
    def system():
        result={'api':'up','database':'down','redis':'down','recommendation':'down'}
        try:ready();result['database']='up'
        except Exception:pass
        try:cache.client.ping();result['redis']='up'
        except Exception:pass
        try:result['recommendation']='up' if httpx.get(os.getenv('RECOMMENDATION_URL','http://recommendation:8000')+'/ready',timeout=2).is_success else 'down'
        except Exception:pass
        return result

from .telemetry import configure
configure(app)
