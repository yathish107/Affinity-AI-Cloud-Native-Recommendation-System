# AI-Powered Cloud-Native Real-Time Recommendation System

A runnable academic project combining the ideas from the three supplied research papers:

1. Event-driven architecture for real-time personalization and recommendation.
2. AI-assisted migration/decomposition toward microservices.
3. Cloud-native AI deployment using containers, orchestration, scaling and monitoring concepts.

## Architecture
Browser -> FastAPI API -> Event Broker -> Recommendation Worker -> SQLite event/profile store -> ML engine -> Recommendations

For the easiest demo, Docker Compose runs the API, worker, frontend and Redpanda broker.

## Requirements
- Windows 10/11
- Docker Desktop
- 8 GB RAM recommended
- VS Code optional

## Run with Docker
Open PowerShell in this folder:

```powershell
docker compose up --build
```

Open:
- Frontend: http://localhost:8080
- API docs: http://localhost:8000/docs
- Health: http://localhost:8000/health

Stop:
```powershell
docker compose down
```

## Demo
1. Enter a user ID such as `student1`.
2. Click product **View**, **Click**, and **Purchase** buttons.
3. Click **Get Recommendations**.
4. The recommendation engine uses the user's interactions, product tags and similarity to generate personalized results.
5. Use different users to demonstrate different profiles.

## Local backend without Docker
```powershell
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
Kafka is optional in local mode; the application falls back to direct processing when the broker is unavailable.

## Kubernetes
The `k8s` folder contains namespace, broker, backend, frontend and HPA manifests.

```powershell
kubectl apply -f k8s/
kubectl get pods -n ai-recommender
```

The Kubernetes frontend uses an nginx reverse proxy so browser requests go through `/api` to the backend service.

## Important academic note
This is a working academic prototype, not a production recommendation platform. The ML model is intentionally lightweight so it can run on a normal laptop. SQLite is used for simplicity; a production deployment should use a shared database such as PostgreSQL or MongoDB.
