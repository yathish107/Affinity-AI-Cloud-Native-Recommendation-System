import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.hybrid import Hybrid

def test_cold_start():
    r=Hybrid().recommend([],[]);assert len(r)==5 and all(x['score']==0 for x in r)
def test_contributions():
    h=[dict(product_id='p1',event_type='click')];s=[dict(user_id=u,product_id=p,weight=2) for u in ['a','b'] for p in ['p1','p3']]
    r=Hybrid().recommend(h,s)
    assert all(x['id']!='p1' and abs(x['score']-sum(x['explanation']['contributions'].values()))<1e-12 for x in r)
    assert r==Hybrid().recommend(h,list(reversed(s)))
def test_popularity():
    assert Hybrid().recommend([],[dict(user_id='a',product_id='p4',weight=1)])[0]['id']=='p4'
