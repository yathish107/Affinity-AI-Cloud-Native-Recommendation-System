import json
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
PRODUCTS=json.loads(Path(__file__).with_name('catalog.json').read_text())
class Hybrid:
    def __init__(self):
        self.index={p['id']:i for i,p in enumerate(PRODUCTS)}
        self.vectorizer=TfidfVectorizer(stop_words='english')
        self.matrix=self.vectorizer.fit_transform([p['tags'] for p in PRODUCTS])
    def recommend(self,history,signals,limit=5,mode='hybrid'):
        preference=np.zeros(len(PRODUCTS));seen=set()
        for e in sorted(history,key=lambda e:(e['product_id'],e['event_type'],float(e.get('dwell_seconds',0)))):
            if e['product_id'] not in self.index:continue
            i=self.index[e['product_id']];seen.add(i)
            preference[i]+={'view':1,'click':2,'purchase':5}[e['event_type']]*(1+min(e.get('dwell_seconds',0),120)/240)
        preference=np.minimum(preference,20)
        users=sorted({e['user_id'] for e in signals});ui={u:i for i,u in enumerate(users)}
        matrix=np.zeros((len(users),len(PRODUCTS)))
        for e in signals:
            if e['product_id'] in self.index:matrix[ui[e['user_id']],self.index[e['product_id']]]=min(e['weight'],20)
        pop=(matrix>0).sum(axis=0).astype(float) if users else np.zeros(len(PRODUCTS))
        if pop.max()>0:pop/=pop.max()
        content=np.zeros(len(PRODUCTS));collab=content.copy()
        profile=np.asarray(preference@self.matrix).reshape(1,-1)
        if preference.sum():content=cosine_similarity(profile,self.matrix).ravel()
        if len(users)>=2 and preference.sum():
            sim=cosine_similarity(matrix.T);np.fill_diagonal(sim,0)
            support=(matrix>0).astype(int).T@(matrix>0).astype(int);sim[support<2]=0
            collab=preference@sim/preference.sum()
        available={'content':bool(content.max()),'collaborative':bool(collab.max()),'popularity':bool(pop.max())}
        weights={'content':.6,'collaborative':.3,'popularity':.1} if mode=='hybrid' else {k:float(k==mode) for k in available}
        denom=sum(weights[k] for k in weights if available[k])
        weights={k:(v/denom if available[k] and denom else 0) for k,v in weights.items()}
        rows=[]
        for i,p in enumerate(PRODUCTS):
            if i in seen:continue
            components=dict(content=float(content[i]),collaborative=float(collab[i]),popularity=float(pop[i]))
            contributions={k:weights[k]*v for k,v in components.items()}
            terms=[]
            if preference.sum():
                overlap=profile.ravel()*self.matrix[i].toarray().ravel()
                terms=[str(self.vectorizer.get_feature_names_out()[j]) for j in np.argsort(-overlap)[:4] if overlap[j]>0]
            reasons=[]
            if contributions['content']:reasons.append('Shared interests: '+', '.join(terms))
            if contributions['collaborative']:reasons.append('Supported by co-interactions from at least two users')
            if contributions['popularity']:reasons.append('Popular among users with processed interactions')
            rows.append({**p,'score':sum(contributions.values()),'explanation':{'components':components,'weights':weights,'contributions':contributions,'reasons':reasons or ['Catalog fallback: insufficient interaction data'],'shared_terms':terms},'model_version':'hybrid-v2'})
        return sorted(rows,key=lambda x:(-x['score'],x['id']))[:limit]
