# Kubernetes deployment

Build images from the project root:

```powershell
docker build -t ai-recommender-backend:latest .\backend
docker build -t ai-recommender-frontend:latest .\frontend
```

For Docker Desktop Kubernetes, apply:

```powershell
kubectl apply -f k8s/
kubectl get pods -n ai-recommender
```

Open http://localhost:30080

If your Kubernetes cluster does not share Docker Desktop's local image cache, load/push the two images according to your cluster provider.
